import React from 'react';
import { Hero } from './components/Hero';
import { Features } from './components/Features/index';
import { HowItWorks } from './components/HowItWorks';
import { Testimonials } from './components/Testimonials';
import { TrustedBy } from './components/TrustedBy';
import { SectorBenefits } from './components/SectorBenefits';
import { Reassurance } from './components/Reassurance';
import { CTA } from './components/CTA';
import { FAQ } from './components/FAQ';
import { Footer } from './components/Footer';
import { Notification } from './components/Notification';
import { SectionTransition } from './components/SectionTransition';
import { ParallaxBackground } from './components/Background/ParallaxBackground';
import { LeadCaptureForm } from './components/LeadCaptureForm';
import { useScroll } from './hooks/useScroll';

function App() {
  const scrollY = useScroll();

  return (
    <div className="min-h-screen relative">
      <ParallaxBackground scrollY={scrollY} />
      
      <div className="relative">
        <Hero />
        <SectionTransition>
          <Features />
        </SectionTransition>
        <SectionTransition>
          <HowItWorks />
        </SectionTransition>
        <SectionTransition>
          <Testimonials />
        </SectionTransition>
        <SectionTransition>
          <TrustedBy />
        </SectionTransition>
        <SectionTransition>
          <SectorBenefits />
        </SectionTransition>
        <SectionTransition>
          <Reassurance />
        </SectionTransition>
        <SectionTransition>
          <CTA />
        </SectionTransition>
        <SectionTransition>
          <FAQ />
        </SectionTransition>
        <SectionTransition>
          <Footer />
        </SectionTransition>
        <Notification />
        <LeadCaptureForm />
      </div>
    </div>
  );
}

export default App;
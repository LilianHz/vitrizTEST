declare global {
  interface Window {
    fbq: any;
  }
}

export const trackEvent = {
  startTrial: () => {
    if (typeof window.fbq !== 'undefined') {
      window.fbq('track', 'StartTrial');
    }
  }
};
export const redirectTo = {
  stripe: () => {
    window.location.href = 'https://vitriz.checkoutpage.co/starter';
  }
};
import { CTAButton } from '../CTAButton';

interface SectionCTAProps {
  text: string;
  compact?: boolean;
  className?: string;
}

export function SectionCTA({ text, compact, className = "" }: SectionCTAProps) {
  return (
    <div className={`py-12 ${className}`}>
      <div className="container mx-auto px-4">
        <div className="text-center">
          <CTAButton customText={text} compact={compact} />
          {!compact && (
            <p className="text-blue-200 text-sm mt-2">
              Sans engagement • Résultats garantis dès la première semaine
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
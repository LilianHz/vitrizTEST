import React from 'react';
import { motion } from 'framer-motion';
import { HeroStats } from './HeroStats';
import { CTAButton } from './CTAButton';
import { ReviewCounter } from './ReviewCounter';
import { PlatformBadges } from './PlatformBadges';
import { Award, Shield } from 'lucide-react';

const partnerships = [
  {
    icon: Award,
    title: 'Google Reviews Pro',
    description: 'Partenaire Officiel',
    color: 'from-blue-500/20 to-blue-600/20',
    textColor: 'text-blue-400'
  },
  {
    icon: Shield,
    title: 'Trusted Business Solutions',
    description: 'Solution Certifiée',
    color: 'from-purple-500/20 to-purple-600/20',
    textColor: 'text-purple-400'
  }
];

const platformsTextVariants = {
  initial: {
    opacity: 0,
    y: 20,
    scale: 0.95
  },
  animate: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.8,
      ease: "easeOut"
    }
  },
  hover: {
    scale: 1.05,
    transition: {
      duration: 0.3,
      ease: "easeInOut"
    }
  }
};

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center py-20 overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col items-center text-center max-w-5xl mx-auto">
          {/* Partnerships Section - Updated for better mobile display */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="grid md:grid-cols-2 gap-2 md:gap-4 mb-8 md:mb-12 w-full max-w-2xl"
          >
            {partnerships.map((partner, index) => (
              <div
                key={index}
                className="relative group"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10 
                              md:from-blue-600/20 md:to-purple-600/20 rounded-lg md:rounded-xl 
                              blur-md md:blur-xl opacity-50 md:opacity-75 
                              group-hover:opacity-100 transition duration-300" />
                <div className="relative bg-gray-800/30 md:bg-gray-800/50 backdrop-blur-sm md:backdrop-blur-lg 
                              p-2 md:p-4 rounded-lg md:rounded-xl border border-gray-700/50 md:border-gray-700 
                              hover:border-blue-500/50 md:hover:border-blue-500 
                              transition-all duration-300 flex items-center gap-2 md:gap-3">
                  <div className={`p-1.5 md:p-2 rounded-md md:rounded-lg 
                                bg-gradient-to-r ${partner.color} opacity-75 md:opacity-100`}>
                    <partner.icon className={`w-4 h-4 md:w-6 md:h-6 ${partner.textColor}`} />
                  </div>
                  <div className="text-left">
                    <h3 className="text-sm md:text-base text-white font-semibold">{partner.title}</h3>
                    <p className="text-xs md:text-sm text-blue-200/75 md:text-blue-200">
                      {partner.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </motion.div>
          
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-5xl md:text-7xl font-bold mb-4 leading-tight"
          >
            <span className="text-white">Triplez vos avis 5 étoiles sur</span>{' '}
            <motion.span
              initial="initial"
              animate="animate"
              whileHover="hover"
              variants={platformsTextVariants}
              className="relative inline-block"
            >
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-700 via-violet-600 to-blue-700 
                           rounded-lg blur-xl opacity-50 animate-gradient" 
                   style={{ backgroundSize: "200% 200%" }} />
              <span className="relative text-transparent bg-clip-text bg-gradient-to-r 
                           from-blue-400 via-violet-400 to-blue-400 animate-gradient"
                   style={{ backgroundSize: "200% 200%" }}>
                toutes les plateformes
              </span>
            </motion.span>
          </motion.h1>

          <ReviewCounter />
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="text-xl md:text-2xl text-blue-100 mb-8 mt-8 max-w-3xl leading-relaxed"
          >
            Rejoignez plus de{' '}
            <span className="font-semibold text-white">1 200 entreprises satisfaites</span>{' '}
            qui ont déjà transformé leur présence en ligne grâce à notre solution innovante.
          </motion.p>

          <PlatformBadges />
          
          <HeroStats />
          
          <div className="mt-12">
            <CTAButton />
          </div>
        </div>
      </div>
    </section>
  );
}
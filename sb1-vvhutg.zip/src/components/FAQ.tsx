import { motion } from 'framer-motion';
import { HelpCircle, ChevronDown } from 'lucide-react';
import { useState } from 'react';

const faqs = [
  {
    question: 'Est-ce que cela fonctionne vraiment ?',
    answer: 'Absolument ! Des centaines d\'entreprises, comme la vôtre, ont vu leur e-réputation décoller grâce à notre solution. Imaginez tripler vos avis 5 étoiles en quelques semaines, comme Marie, qui a atteint le Top 3 Google en seulement 30 jours. Vous pourriez être notre prochain succès !'
  },
  {
    question: 'Dois-je être un expert technique pour utiliser ce logiciel ?',
    answer: 'Pas besoin d\'être un technophile ! Comme le dit Antoine, un médecin généraliste qui utilise notre solution : "Je n\'ai eu besoin que de 5 minutes pour tout configurer et mes patients laissent maintenant des avis sans que j\'aie à intervenir."'
  },
  {
    question: 'Y a-t-il un engagement ?',
    answer: 'Pas du tout. Vous êtes libre comme l\'air ! Vous pouvez essayer, profiter des résultats, et arrêter à tout moment. Mais honnêtement, peu de nos clients le font – les résultats parlent d\'eux-mêmes.'
  },
  {
    question: 'Combien cela coûte-t-il ?',
    answer: 'Exceptionnellement, le premier mois est à 27€ au lieu de 69€ ! Une offre limitée à saisir rapidement.'
  },
  {
    question: 'Que se passe-t-il si je reçois un avis négatif ?',
    answer: 'Pas d\'inquiétude ! Notre système vous alerte immédiatement et vous permet de gérer ces retours de manière privée avant qu\'ils ne soient visibles en ligne. Cela vous donne l\'opportunité d\'apaiser vos clients et de préserver votre e-réputation.'
  }
];

function FAQItem({ question, answer, index }: { question: string; answer: string; index: number }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="relative group"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                    rounded-2xl blur-xl opacity-75 group-hover:opacity-100 transition duration-300" />
      <div className="relative bg-gray-800/50 backdrop-blur-lg rounded-2xl border 
                    border-gray-700 hover:border-blue-500 transition-all duration-300 overflow-hidden">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full p-6 text-left flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <div className="p-2 rounded-lg bg-gradient-to-r from-blue-500/20 to-blue-600/20">
              <HelpCircle className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-white">{question}</h3>
          </div>
          <ChevronDown
            className={`w-5 h-5 text-blue-400 transition-transform duration-300 ${
              isOpen ? 'rotate-180' : ''
            }`}
          />
        </button>
        <motion.div
          initial={false}
          animate={{ height: isOpen ? 'auto' : 0 }}
          transition={{ duration: 0.3 }}
          className="overflow-hidden"
        >
          <div className="p-6 pt-0 text-gray-300">{answer}</div>
        </motion.div>
      </div>
    </motion.div>
  );
}

export function FAQ() {
  return (
    <section className="py-32">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Questions{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-200">
              fréquentes
            </span>
          </h2>
          <div className="w-24 h-1 bg-blue-500 mx-auto" />
        </motion.div>

        <div className="max-w-4xl mx-auto space-y-6">
          {faqs.map((faq, index) => (
            <FAQItem key={index} {...faq} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
import { motion } from 'framer-motion';
import { Globe, Shield, Mail, FileText } from 'lucide-react';
import { CTAButton } from './CTAButton';
import { useState } from 'react';
import { TermsModal } from './Terms';
import { ContactModal } from './ContactModal';

const certifications = [
  {
    icon: Globe,
    title: 'Partenaire Certifié',
    description: 'Google Reviews Pro',
    color: 'from-blue-500/20 to-blue-600/20',
    textColor: 'text-blue-400'
  },
  {
    icon: Shield,
    title: 'Solution Certifiée',
    description: 'Trusted Business Solutions',
    color: 'from-purple-500/20 to-purple-600/20',
    textColor: 'text-purple-400'
  }
];

const footerLinks = [
  {
    icon: Mail,
    title: 'Contact',
    action: 'contact',
    color: 'from-green-500/20 to-green-600/20',
    textColor: 'text-green-400'
  },
  {
    icon: FileText,
    title: 'CGU',
    action: 'terms',
    color: 'from-orange-500/20 to-orange-600/20',
    textColor: 'text-orange-400'
  }
];

export function Footer() {
  const [isTermsModalOpen, setIsTermsModalOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);

  const handleLinkClick = (action: string) => {
    if (action === 'terms') {
      setIsTermsModalOpen(true);
    } else if (action === 'contact') {
      setIsContactModalOpen(true);
    }
  };

  return (
    <footer className="py-12">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="relative group max-w-4xl mx-auto"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                        rounded-2xl blur-xl opacity-75 group-hover:opacity-100 transition duration-300" />
          <div className="relative bg-gray-800/50 backdrop-blur-lg p-8 rounded-2xl border 
                        border-gray-700 hover:border-blue-500 transition-all duration-300">
            {/* Final CTA Section */}
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
                Prêt à transformer votre{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-200">
                  présence en ligne
                </span>
                ?
              </h2>
              <p className="text-xl text-blue-100 mb-8">
                Rejoignez les entreprises qui excellent déjà grâce à notre solution
              </p>
              <CTAButton customText="Ne ratez pas vos 14 jours d'essai gratuits ! 🎁" compact />
            </div>

            {/* Certifications and Links */}
            <div className="grid md:grid-cols-2 gap-8 mb-8 border-t border-gray-700 pt-8">
              {certifications.map((cert, index) => (
                <div key={index} className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg bg-gradient-to-r ${cert.color}`}>
                    <cert.icon className={`w-6 h-6 ${cert.textColor}`} />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">{cert.title}</h3>
                    <p className="text-blue-200">{cert.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Footer Links */}
            <div className="flex justify-center gap-4 border-t border-gray-700 pt-8">
              {footerLinks.map((link, index) => (
                <button
                  key={index}
                  onClick={() => handleLinkClick(link.action)}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-800/50 
                           border border-gray-700 hover:border-blue-500 transition-all duration-300"
                >
                  <div className={`p-1 rounded-lg bg-gradient-to-r ${link.color}`}>
                    <link.icon className={`w-4 h-4 ${link.textColor}`} />
                  </div>
                  <span className="text-white">{link.title}</span>
                </button>
              ))}
            </div>
            
            <div className="text-center border-t border-gray-700 pt-8 mt-8">
              <p className="text-gray-400">© 2024 - Vitriz. Tous droits réservés.</p>
            </div>
          </div>
        </motion.div>
      </div>

      <TermsModal 
        isOpen={isTermsModalOpen}
        onClose={() => setIsTermsModalOpen(false)}
      />
      
      <ContactModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
      />
    </footer>
  );
}
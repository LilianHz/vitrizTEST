import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Marie S.',
    role: '💇‍♀️ Salon de Coiffure',
    content: 'Je suis passée de 10 à 50 avis 5 étoiles par mois, non seulement sur Google mais aussi sur TheFork et Facebook. J\'ai atteint le Top 3 Google local en un mois et ma visibilité s\'est envolée !',
    metric: '🚀 +400% d\'avis positifs en 30 jours',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200&h=200'
  },
  {
    name: 'Dr. Antoine M.',
    role: '👨‍⚕️ Médecin Généraliste',
    content: 'J\'ai triplé le trafic sur ma fiche Google et reçu des avis positifs sur d\'autres plateformes. Plus de patients, sans effort supplémentaire.',
    metric: '📈 Visibilité multipliée par 3',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=200&h=200'
  },
  {
    name: 'Louis R.',
    role: '👨‍🍳 Restaurateur',
    content: 'Avant, je peinais à obtenir des avis. Aujourd\'hui, chaque jour, de nouveaux avis 5 étoiles arrivent sur TripAdvisor, Booking et Facebook. Mes ventes ont grimpé de 35%.',
    metric: '⭐ Une crédibilité renforcée',
    image: 'https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?auto=format&fit=crop&q=80&w=200&h=200'
  },
  {
    name: 'Sophie L.',
    role: '👗 Boutique de Mode',
    content: 'Avant, mes clientes hésitaient à laisser des avis. Maintenant, chaque semaine, je reçois un flux régulier d\'évaluations 5 étoiles, non seulement sur Google, mais aussi sur Facebook et d\'autres plateformes. En un mois, mes ventes en ligne ont augmenté de 20% et le trafic en boutique s\'est nettement intensifié.',
    metric: '💫 Ventes en ligne +20%',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200&h=200'
  },
  {
    name: 'Karim A.',
    role: '🏨 Gérant d\'Hôtel',
    content: 'Grâce à la collecte d\'avis sur Booking, TripAdvisor et Google, mon hôtel a vu son taux d\'occupation grimper rapidement. Les clients se sentent rassurés et ma réputation locale s\'est considérablement renforcée. Depuis que j\'utilise cette solution, mes réservations directes ont augmenté de 25%.',
    metric: '📅 Réservations +25%',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200&h=200'
  },
  {
    name: 'Claire D.',
    role: '🧘‍♀️ Centre de Bien-Être',
    content: 'Je cherchais un moyen de me distinguer dans un secteur très concurrentiel. Aujourd\'hui, j\'obtiens régulièrement des avis 5 étoiles sur plusieurs plateformes, ce qui rassure les nouveaux clients. Résultat : une fréquentation en hausse de 30% et des clients plus enclins à recommander mon centre à leur entourage.',
    metric: '🌟 Fréquentation +30%',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200&h=200'
  }
];

export function Testimonials() {
  return (
    <section className="py-32">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Des résultats{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-200">
              réels
            </span>
            , rapidement
          </h2>
          <div className="w-24 h-1 bg-blue-500 mx-auto" />
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                            rounded-2xl blur-xl opacity-75 group-hover:opacity-100 transition duration-300" />
              <div className="relative bg-gray-800/50 backdrop-blur-lg p-8 rounded-2xl border 
                            border-gray-700 hover:border-blue-500 transition-all duration-300">
                <Quote className="w-12 h-12 text-blue-400 mb-6 opacity-50" />
                
                <div className="flex items-center gap-4 mb-6">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover border-2 border-blue-500"
                  />
                  <div>
                    <h3 className="text-xl font-semibold text-white">{testimonial.name}</h3>
                    <p className="text-blue-400">{testimonial.role}</p>
                  </div>
                </div>

                <div className="flex items-center gap-1 text-yellow-400 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>

                <h4 className="text-xl font-semibold text-blue-400 mb-4">
                  {testimonial.metric}
                </h4>

                <p className="text-gray-300">{testimonial.content}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
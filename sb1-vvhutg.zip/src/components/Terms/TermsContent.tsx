import { termsAndConditions } from './termsData';
import { TermsSection } from './TermsSection';

export function TermsContent() {
  return (
    <div className="prose prose-invert max-w-none">
      <h2 className="text-2xl md:text-3xl font-bold text-white mb-6 md:mb-8">
        {termsAndConditions.title}
      </h2>
      
      {termsAndConditions.sections.map((section, index) => (
        <div key={index} className="mb-8 md:mb-12">
          <h3 className="text-xl md:text-2xl font-semibold text-white mb-4 md:mb-6">
            {section.title}
          </h3>
          
          {section.content.map((item, itemIndex) => (
            <TermsSection
              key={itemIndex}
              title={item.title}
              content={item.content}
              subsections={item.subsections}
            />
          ))}
        </div>
      ))}
      
      <div className="mt-6 md:mt-8 p-3 md:p-4 bg-blue-900/20 rounded-lg border border-blue-500/20">
        <p className="text-sm md:text-base text-blue-200">
          Pour toute question concernant ces termes et conditions, veuillez nous contacter à{' '}
          <a href="mailto:contact@vitriz.org" className="text-blue-400 hover:text-blue-300">
            contact@vitriz.org
          </a>
        </p>
      </div>
    </div>
  );
}
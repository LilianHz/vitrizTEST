export const termsAndConditions = {
  title: "Termes et conditions",
  sections: [
    {
      title: "Contrat d'abonnement SaaS",
      content: [
        {
          id: "1",
          title: "Objet du contrat",
          content: "Le présent contrat a pour objet de définir les conditions dans lesquelles le Prestataire fournit au Client un accès à sa plateforme SaaS et aux services associés."
        },
        {
          id: "2",
          title: "Description des services",
          content: "Le Prestataire propose trois formules d'abonnement donnant accès aux fonctionnalités suivantes :",
          subsections: [
            {
              title: "2.1 Formule Starter (69€ HT/mois ou 704€ HT/an)",
              items: [
                "1 Lieu",
                "Widgets d'évaluation",
                "Rappels par SMS",
                "Rappels par e-mail",
                "Tableau de bord des Statistiques",
                "150 emails mensuels",
                "45 SMS mensuels",
                "500 messages WhatsApp"
              ]
            },
            {
              title: "2.2 Formule Pro (89€ HT/mois ou 908€ HT/an)",
              items: [
                "1 Lieu",
                "Widgets d'évaluation",
                "Intégrations illimitées",
                "Rappels par SMS",
                "Rappels par e-mail",
                "Partage sur les réseaux sociaux",
                "Réponse de l'IA",
                "500 emails mensuels",
                "90 SMS mensuels",
                "WhatsApp illimité"
              ]
            },
            {
              title: "2.3 Formule Expansion (139€ HT/mois ou 1418€ HT/an)",
              items: [
                "3 Lieux",
                "Widgets d'évaluation",
                "Rappels par SMS",
                "Rappels par e-mail",
                "Partage sur les réseaux sociaux",
                "Réponse de l'IA",
                "1250 emails mensuels",
                "300 SMS mensuels",
                "WhatsApp illimité"
              ]
            }
          ]
        },
        // ... rest of the content remains the same until pricing section
        {
          id: "4",
          title: "Tarification",
          content: "Le prix de l'abonnement est fixé selon les formules suivantes :",
          subsections: [
            {
              title: "Abonnement mensuel :",
              items: [
                "Formule Starter : 69€ HT par mois",
                "Formule Pro : 89€ HT par mois",
                "Formule Expansion : 139€ HT par mois"
              ]
            },
            {
              title: "Abonnement annuel :",
              items: [
                "Formule Starter : 704€ HT par an",
                "Formule Pro : 908€ HT par an",
                "Formule Expansion : 1 418€ HT par an"
              ]
            },
            {
              content: "Les prix sont susceptibles d'évoluer. Toute modification tarifaire sera notifiée au Client au moins un (1) mois avant son entrée en vigueur."
            }
          ]
        }
        // ... rest of the file remains unchanged
      ]
    },
    {
      title: "Conditions Générales de Vente",
      content: [
        // ... previous content remains the same
        {
          id: "2",
          title: "Description du service",
          content: "Vitriz est une plateforme SaaS permettant [brève description de votre service]. Le service est proposé sous forme d'abonnement mensuel selon trois formules : Starter, Pro et Expansion."
        }
        // ... rest of the content remains unchanged
      ]
    }
  ]
};
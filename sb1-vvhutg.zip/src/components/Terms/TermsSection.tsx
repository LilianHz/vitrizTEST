import { motion } from 'framer-motion';

interface TermsSectionProps {
  title: string;
  content?: string;
  subsections?: {
    title?: string;
    content?: string;
    items?: string[];
  }[];
}

export function TermsSection({ title, content, subsections }: TermsSectionProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="mb-6 md:mb-8"
    >
      <h4 className="text-lg md:text-xl font-semibold text-white mb-3 md:mb-4">{title}</h4>
      {content && <p className="text-sm md:text-base text-gray-300 mb-3 md:mb-4">{content}</p>}
      
      {subsections && subsections.map((subsection, index) => (
        <div key={index} className="ml-3 md:ml-4 mb-3 md:mb-4">
          {subsection.title && (
            <h5 className="text-base md:text-lg font-medium text-white mb-2">
              {subsection.title}
            </h5>
          )}
          {subsection.content && (
            <p className="text-sm md:text-base text-gray-300 mb-2">{subsection.content}</p>
          )}
          {subsection.items && (
            <ul className="list-disc list-inside text-sm md:text-base text-gray-300 space-y-1">
              {subsection.items.map((item, itemIndex) => (
                <li key={itemIndex}>{item}</li>
              ))}
            </ul>
          )}
        </div>
      ))}
    </motion.div>
  );
}
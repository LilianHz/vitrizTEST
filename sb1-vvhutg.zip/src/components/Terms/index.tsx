import { TermsModal } from './TermsModal';

export { TermsModal };
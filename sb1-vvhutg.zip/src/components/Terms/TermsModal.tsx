import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { useEffect } from 'react';
import { TermsContent } from './TermsContent';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TermsModal({ isOpen, onClose }: TermsModalProps) {
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 flex items-center justify-center z-50 p-3 md:p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-4xl max-h-[85vh] md:max-h-[90vh] bg-gray-900/95 
                      backdrop-blur-lg rounded-xl md:rounded-2xl border border-gray-700 
                      shadow-xl overflow-hidden"
          >
            {/* Header with sticky close button */}
            <div className="sticky top-0 z-10 flex justify-end p-3 md:p-4 bg-gray-900/95 
                          border-b border-gray-700">
              <button
                onClick={onClose}
                className="p-1.5 md:p-2 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 
                         border border-gray-700 hover:border-gray-600 transition-all duration-200"
              >
                <X className="w-4 h-4 md:w-5 md:h-5 text-gray-400" />
              </button>
            </div>

            {/* Scrollable content */}
            <div className="overflow-y-auto max-h-[calc(85vh-4rem)] md:max-h-[calc(90vh-5rem)] 
                          p-6 md:p-8">
              <TermsContent />
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
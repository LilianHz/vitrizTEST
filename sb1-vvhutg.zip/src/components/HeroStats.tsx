import { motion } from 'framer-motion';
import { Star, TrendingUp, Award } from 'lucide-react';

const stats = [
  {
    icon: Star,
    text: '+400% d\'avis 5 étoiles en moyenne',
    color: 'text-yellow-400',
    gradient: 'from-yellow-600/20 to-orange-600/20',
    border: 'border-yellow-400/20'
  },
  {
    icon: TrendingUp,
    text: '+30% de ventes dès le premier mois',
    color: 'text-green-400',
    gradient: 'from-green-600/20 to-emerald-600/20',
    border: 'border-green-400/20'
  },
  {
    icon: Award,
    text: 'Classement Google local Top 3 garanti',
    color: 'text-blue-400',
    gradient: 'from-blue-600/20 to-cyan-600/20',
    border: 'border-blue-400/20'
  }
];

export function HeroStats() {
  return (
    <div className="grid md:grid-cols-3 gap-8 mb-16">
      {stats.map((stat, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: index * 0.2 }}
          className="relative group"
        >
          <div className={`absolute -inset-0.5 bg-gradient-to-r ${stat.gradient} 
                          rounded-xl blur-xl opacity-75 group-hover:opacity-100 
                          transition duration-300`} />
          <div className={`relative bg-gray-900/50 backdrop-blur-lg rounded-xl p-6 
                          border ${stat.border} flex items-center gap-4 
                          hover:bg-gray-800/50 transition duration-300`}>
            <div className={`p-3 rounded-lg bg-gradient-to-r ${stat.gradient}`}>
              <stat.icon className={`w-8 h-8 ${stat.color}`} />
            </div>
            <span className="text-lg font-medium text-white">{stat.text}</span>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
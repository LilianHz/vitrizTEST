import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';
import { CTAButton } from './CTAButton';

const benefits = [
  'Résultats garantis dès la première semaine',
  'Sans engagement',
  'Support client 7j/7',
  'Installation en 5 minutes'
];

export function CTA() {
  return (
    <section className="py-32">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Une opportunité à{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-200">
                saisir maintenant
              </span>
            </h2>
            <div className="w-24 h-1 bg-blue-500 mx-auto mb-8" />
            <p className="text-xl text-blue-100">
              Ne laissez pas vos concurrents vous distancer. Chaque jour sans avis supplémentaires 
              est une opportunité manquée.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {benefits.map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="relative group"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                              rounded-xl blur-xl opacity-75 group-hover:opacity-100 transition duration-300" />
                <div className="relative bg-gray-800/50 backdrop-blur-lg p-6 rounded-xl 
                              border border-gray-700 hover:border-blue-500 transition-all duration-300 
                              flex items-center gap-4">
                  <div className="p-2 rounded-lg bg-gradient-to-r from-green-500/20 to-green-600/20">
                    <CheckCircle2 className="w-6 h-6 text-green-400" />
                  </div>
                  <span className="text-white text-lg">{benefit}</span>
                </div>
              </motion.div>
            ))}
          </div>
          
          <CTAButton customText="Lancez votre essai gratuit maintenant" />
        </motion.div>
      </div>
    </section>
  );
}
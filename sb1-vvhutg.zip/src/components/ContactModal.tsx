import { motion, AnimatePresence } from 'framer-motion';
import { X, Mail } from 'lucide-react';
import { useEffect } from 'react';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ContactModal({ isOpen, onClose }: ContactModalProps) {
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 flex items-center justify-center z-50 p-3 md:p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-lg bg-gray-900/95 backdrop-blur-lg 
                      rounded-xl md:rounded-2xl border border-gray-700 shadow-xl overflow-hidden"
          >
            {/* Header with sticky close button */}
            <div className="sticky top-0 z-10 flex justify-end p-3 md:p-4 bg-gray-900/95 border-b border-gray-700">
              <button
                onClick={onClose}
                className="p-1.5 md:p-2 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 
                         border border-gray-700 hover:border-gray-600 transition-all duration-200"
              >
                <X className="w-4 h-4 md:w-5 md:h-5 text-gray-400" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 md:p-8">
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-6 md:mb-8">Contactez-nous</h2>
              
              <motion.a
                href="mailto:contact@vitriz.org"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="relative group block"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                              rounded-lg md:rounded-xl blur-lg opacity-75 group-hover:opacity-100 
                              transition duration-300" />
                <div className="relative bg-gray-800/50 backdrop-blur-lg p-4 md:p-6 rounded-lg md:rounded-xl 
                              border border-gray-700 hover:border-blue-500 transition-all duration-300 
                              flex items-center gap-3 md:gap-4">
                  <div className="p-2 md:p-3 rounded-lg bg-gradient-to-r from-blue-500/20 to-blue-600/20">
                    <Mail className="w-5 h-5 md:w-6 md:h-6 text-blue-400" />
                  </div>
                  <div>
                    <h3 className="text-base md:text-lg font-semibold text-white">Email</h3>
                    <p className="text-sm md:text-base text-gray-300">contact@vitriz.org</p>
                  </div>
                </div>
              </motion.a>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
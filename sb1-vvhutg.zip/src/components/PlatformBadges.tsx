import { useEffect, useRef } from 'react';
import { motion, useAnimationControls } from 'framer-motion';

const platforms = [
  { name: 'Google', icon: '🔍' },
  { name: 'Facebook', icon: '👥' },
  { name: 'Trustpilot', icon: '⭐' },
  { name: 'Tripadvisor', icon: '✈️' },
  { name: 'Booking.com', icon: '🏨' },
  { name: 'Airbnb', icon: '🏠' },
  { name: 'GooglePlay', icon: '📱' },
  { name: 'AppStore', icon: '🍎' },
  { name: 'Yelp', icon: '📋' },
  { name: 'Pages Jaunes', icon: '📖' },
  { name: 'eBay', icon: '🛍️' },
  { name: 'Hotels.com', icon: '🛎️' },
  { name: 'Foursquare', icon: '📍' },
  { name: 'Etsy', icon: '🎨' },
  { name: 'Intégration personnalisée', icon: '🔧' }
];

// Double the platforms array for seamless scrolling
const allPlatforms = [...platforms, ...platforms];

export function PlatformBadges() {
  const containerRef = useRef<HTMLDivElement>(null);
  const controls = useAnimationControls();

  useEffect(() => {
    const scroll = async () => {
      if (!containerRef.current) return;
      
      const containerWidth = containerRef.current.scrollWidth / 2;
      
      await controls.start({
        x: -containerWidth,
        transition: {
          duration: 30, // Increased duration for slower scrolling
          ease: "linear",
          repeat: Infinity
        }
      });
    };

    scroll();
  }, [controls]);

  return (
    <div className="w-full overflow-hidden mb-12">
      <motion.div
        ref={containerRef}
        animate={controls}
        className="flex gap-4 whitespace-nowrap"
      >
        {allPlatforms.map((platform, index) => (
          <motion.div
            key={index}
            whileHover={{ scale: 1.05 }}
            className="flex items-center gap-2 bg-gray-800/50 backdrop-blur-lg px-4 py-2 rounded-full
                     border border-gray-700 hover:border-blue-500 transition-all duration-300"
          >
            <span className="text-2xl">{platform.icon}</span>
            <span className="text-white font-medium">{platform.name}</span>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
import { motion } from 'framer-motion';
import { Building2 } from 'lucide-react';

const sectors = [
  { name: 'Bars', emoji: '🍺' },
  { name: 'Restaurants', emoji: '🍽️' },
  { name: 'Hôtels', emoji: '🏨' },
  { name: 'Cabinets médicaux', emoji: '⚕️' },
  { name: 'Salons de coiffure', emoji: '💇' },
  { name: 'Boutiques de mode', emoji: '👗' },
  { name: 'Agences immobilières', emoji: '🏠' }
];

export function TrustedBy() {
  return (
    <section className="py-32">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ils nous font{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-200">
              confiance
            </span>
          </h2>
          <div className="w-24 h-1 bg-blue-500 mx-auto mb-8" />
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Des centaines d'entreprises de secteurs variés utilisent déjà notre solution
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="relative group max-w-4xl mx-auto"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                        rounded-2xl blur-xl opacity-75 group-hover:opacity-100 transition duration-300" />
          <div className="relative bg-gray-800/50 backdrop-blur-lg p-8 rounded-2xl border 
                        border-gray-700 hover:border-blue-500 transition-all duration-300">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-2 rounded-lg bg-gradient-to-r from-blue-500/20 to-blue-600/20">
                <Building2 className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="text-xl font-semibold text-white">Secteurs d'activité</h3>
            </div>
            <div className="flex flex-wrap gap-4">
              {sectors.map((sector, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="bg-blue-500/10 px-4 py-2 rounded-full border border-blue-500/20 
                            flex items-center gap-2"
                >
                  <span className="text-2xl">{sector.emoji}</span>
                  <span className="text-blue-200">{sector.name}</span>
                </motion.div>
              ))}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: sectors.length * 0.1 }}
                className="bg-blue-500/10 px-4 py-2 rounded-full border border-blue-500/20 
                          flex items-center gap-2"
              >
                <span className="text-2xl">✨</span>
                <span className="text-blue-200">Et bien d'autres...</span>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, X } from 'lucide-react';
import { useState, useEffect } from 'react';

const notifications = [
  'Marie S. vient de booster sa fiche Google avec 5 nouveaux avis !',
  'Pierre L. a atteint le Top 3 Google en seulement 3 semaines !',
  'Sophie M. a doublé ses avis 5 étoiles ce mois-ci !'
];

export function Notification() {
  const [isVisible, setIsVisible] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    if (isDismissed) return; // Don't show notifications if dismissed

    // Initial delay before showing first notification
    const showTimeout = setTimeout(() => setIsVisible(true), 3000);
    
    const interval = setInterval(() => {
      setIsVisible(false);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % notifications.length);
        setIsVisible(true);
      }, 800); // Longer fade out transition
    }, 12000); // Longer display time

    return () => {
      clearTimeout(showTimeout);
      clearInterval(interval);
    };
  }, [isDismissed]);

  const handleClose = () => {
    setIsVisible(false);
    setIsDismissed(true);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 md:bottom-8 md:right-8">
      <AnimatePresence mode="wait">
        {isVisible && !isDismissed && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.3 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.5, transition: { duration: 0.5 } }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                          rounded-xl blur-xl opacity-75 group-hover:opacity-100 transition duration-500" />
            <div className="relative flex items-center gap-3 bg-gray-800/90 backdrop-blur-lg p-4 
                          rounded-xl border border-gray-700 hover:border-blue-500 transition-all 
                          duration-500 max-w-sm shadow-lg pr-12">
              <div className="p-2 rounded-lg bg-blue-500/20">
                <Bell className="w-6 h-6 text-blue-400" />
              </div>
              <p className="text-sm text-white">{notifications[currentIndex]}</p>
              <button
                onClick={handleClose}
                className="absolute top-4 right-4 p-1 rounded-lg bg-gray-700/50 hover:bg-gray-600/50 
                         border border-gray-600 hover:border-gray-500 transition-all duration-200"
              >
                <X className="w-4 h-4 text-gray-400" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
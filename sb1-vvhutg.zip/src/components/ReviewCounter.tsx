import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

export function ReviewCounter() {
  const [count, setCount] = useState(12499);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setCount(prev => prev + Math.floor(Math.random() * 3) + 1);
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500/20 to-purple-500/20 
                backdrop-blur-md rounded-full px-4 py-2 border border-blue-400/20"
    >
      <Star className="w-4 h-4 text-yellow-400" />
      <span className="text-white font-semibold">
        {count.toLocaleString('fr-FR')}
      </span>
      <span className="text-blue-200 text-sm">
        avis générés
      </span>
    </motion.div>
  );
}
import { motion } from 'framer-motion';
import { Utensils, Building, Heart, ShoppingBag } from 'lucide-react';

const sectors = [
  {
    icon: Utensils,
    title: 'Restauration',
    description: 'Remplissez votre salle grâce aux avis sur TheFork, TripAdvisor, Google, Yelp, Pages Jaunes et Facebook.',
    color: 'from-orange-500 to-orange-600'
  },
  {
    icon: Building,
    title: 'Hôtellerie & Hébergement',
    description: 'Faites grimper vos réservations sur Booking.com, Airbnb, Hotels.com, TripAdvisor, Google Maps et Trustpilot.',
    color: 'from-blue-500 to-blue-600'
  },
  {
    icon: Heart,
    title: 'Santé & Bien-être',
    description: 'Attirez plus de patients grâce à une réputation solide sur Google, Facebook, Pages Jaunes, Foursquare et Trustpilot.',
    color: 'from-green-500 to-green-600'
  },
  {
    icon: ShoppingBag,
    title: 'Commerce de Détail & Services',
    description: 'Augmentez vos ventes en affichant des avis 5 étoiles sur Google, Facebook, Trustpilot, eBay, Etsy et d\'autres plateformes spécialisées.',
    color: 'from-purple-500 to-purple-600'
  }
];

export function SectorBenefits() {
  return (
    <section className="py-32">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Pour tous les secteurs,{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-200">
              des bénéfices concrets
            </span>
          </h2>
          <div className="w-24 h-1 bg-blue-500 mx-auto" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {sectors.map((sector, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                            rounded-2xl blur-xl opacity-75 group-hover:opacity-100 transition duration-300" />
              <div className="relative bg-gray-800/50 backdrop-blur-lg p-8 rounded-2xl border 
                            border-gray-700 hover:border-blue-500 transition-all duration-300">
                <div className={`inline-flex p-3 rounded-lg bg-gradient-to-r ${sector.color} mb-6`}>
                  <sector.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">{sector.title}</h3>
                <p className="text-gray-300">{sector.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
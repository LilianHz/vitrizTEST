import { Button } from './ui/Button';
import { ReassuranceBadge } from './ui/ReassuranceBadge';
import { UrgencyCounter } from './ui/UrgencyCounter';
import { trackEvent } from '../utils/analytics';
import { redirectTo } from '../utils/navigation';

interface CTAButtonProps {
  className?: string;
  compact?: boolean;
  customText?: string;
}

export function CTAButton({ className, compact, customText }: CTAButtonProps) {
  const handleClick = () => {
    trackEvent.startTrial();
    redirectTo.stripe();
  };

  const buttonText = customText || (compact 
    ? "Commencer maintenant"
    : "Découvrez votre score d'avis en 1 clic");

  return (
    <div className={`flex flex-col items-center gap-4 ${className}`}>
      {!compact && <UrgencyCounter />}
      <Button 
        text={buttonText}
        onClick={handleClick}
      />
      {!compact && <ReassuranceBadge />}
    </div>
  );
}
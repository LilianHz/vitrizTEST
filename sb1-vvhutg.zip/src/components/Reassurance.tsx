import { motion } from 'framer-motion';
import { Shield, Zap, Award } from 'lucide-react';

const features = [
  {
    icon: Award,
    title: 'Partenaires Officiels et Certifiés',
    description: 'Notre solution est reconnue par Google Reviews Pro et Trusted Business Solutions.',
    color: 'from-blue-500 to-blue-600'
  },
  {
    icon: Shield,
    title: 'Sécurité & Confidentialité',
    description: 'Vos données et celles de vos clients sont protégées.',
    color: 'from-green-500 to-green-600'
  },
  {
    icon: Zap,
    title: 'Innovation Continue',
    description: 'Notre IA est régulièrement mise à jour pour maximiser votre visibilité et votre réputation.',
    color: 'from-purple-500 to-purple-600'
  }
];

export function Reassurance() {
  return (
    <section className="py-32">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Réassurance et{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-200">
              crédibilité
            </span>
          </h2>
          <div className="w-24 h-1 bg-blue-500 mx-auto" />
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                            rounded-2xl blur-xl opacity-75 group-hover:opacity-100 transition duration-300" />
              <div className="relative bg-gray-800/50 backdrop-blur-lg p-8 rounded-2xl border 
                            border-gray-700 hover:border-blue-500 transition-all duration-300">
                <div className={`inline-flex p-3 rounded-lg bg-gradient-to-r ${feature.color} mb-6`}>
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">{feature.title}</h3>
                <p className="text-gray-300">{feature.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
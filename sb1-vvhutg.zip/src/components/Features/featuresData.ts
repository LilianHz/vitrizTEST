import { Bot, MessageSquare, Shield, Share2, Globe } from 'lucide-react';

export const features = [
  {
    icon: Bot,
    title: 'Collecte Automatique d\'Avis 5 Étoiles Multi-Plateformes',
    description: 'Notre IA identifie vos clients satisfaits et les incite à laisser un avis positif, non seulement sur Google, mais aussi sur TheFork, TripAdvisor, Booking, Facebook et d\'autres canaux stratégiques. Vous maximisez votre réputation sans effort.',
    color: 'from-purple-500 to-purple-600'
  },
  {
    icon: MessageSquare,
    title: 'Réponses Personnalisées et Professionnelles',
    description: 'L\'IA rédige des réponses chaleureuses et adaptées à chaque avis, renforçant votre image de marque sur toutes les plateformes clés.',
    color: 'from-blue-500 to-blue-600'
  },
  {
    icon: Shield,
    title: 'Filtrage Intelligent des Avis Négatifs',
    description: 'Les retours insatisfaits sont gérés en privé. Vous pouvez ainsi intervenir avant que ces avis n\'impactent votre image publique.',
    color: 'from-green-500 to-green-600'
  },
  {
    icon: Share2,
    title: 'Contenu Marketing Clé en Main',
    description: 'Transformez vos meilleurs avis en visuels attrayants pour vos réseaux sociaux, votre site web et vos newsletters, afin de renforcer votre notoriété.',
    color: 'from-orange-500 to-orange-600'
  },
  {
    icon: Globe,
    title: 'Suivi Statistique et Tableau de Bord Simplifié',
    description: 'Surveillez votre note globale, le volume d\'avis, votre trafic et vos ventes sur un seul tableau de bord. Tout est centralisé.',
    color: 'from-red-500 to-red-600'
  }
];
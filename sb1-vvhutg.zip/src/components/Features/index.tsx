import { motion } from 'framer-motion';
import { FeatureCard } from './FeatureCard';
import { features } from './featuresData';

export function Features() {
  return (
    <section className="py-32">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Pourquoi notre solution est{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-200">
              essentielle pour votre entreprise
            </span>
            ?
          </h2>
          <div className="w-24 h-1 bg-blue-500 mx-auto mb-6" />
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Une solution unique pour dominer toutes les plateformes d'avis et maximiser votre visibilité en ligne
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard key={index} {...feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  color: string;
  index: number;
}

export function FeatureCard({ icon: Icon, title, description, color, index }: FeatureCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="relative group"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                    rounded-2xl blur-xl opacity-75 group-hover:opacity-100 transition duration-300" />
      <div className="relative bg-gray-800/50 backdrop-blur-lg p-8 rounded-2xl border 
                    border-gray-700 hover:border-blue-500 transition-all duration-300">
        <div className={`inline-flex p-3 rounded-lg bg-gradient-to-r ${color} mb-6`}>
          <Icon className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-xl font-semibold text-white mb-4">{title}</h3>
        <p className="text-gray-300">{description}</p>
      </div>
    </motion.div>
  );
}
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { useEffect } from 'react';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TermsModal({ isOpen, onClose }: TermsModalProps) {
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 flex items-center justify-center z-50">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-4xl mx-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="relative bg-gray-900/95 backdrop-blur-lg rounded-2xl border border-gray-700 
                          shadow-xl overflow-hidden">
              {/* Close button */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 p-2 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 
                         border border-gray-700 hover:border-gray-600 transition-all duration-200"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>

              {/* Content */}
              <div className="p-8">
                <h2 className="text-3xl font-bold text-white mb-8">Termes et conditions</h2>
                
                <div className="prose prose-invert max-w-none">
                  <h3 className="text-2xl font-semibold text-white mb-4">Contrat d'abonnement SaaS</h3>
                  
                  <h4 className="text-xl font-semibold text-white mt-6 mb-3">1. Objet du contrat</h4>
                  <p className="text-gray-300 mb-4">
                    Le présent contrat a pour objet de définir les conditions dans lesquelles le Prestataire 
                    fournit au Client un accès à sa plateforme SaaS et aux services associés.
                  </p>

                  {/* Add the rest of your terms content here */}
                  
                  <div className="mt-8 p-4 bg-blue-900/20 rounded-lg border border-blue-500/20">
                    <p className="text-blue-200 text-sm">
                      Pour toute question concernant ces termes et conditions, veuillez nous contacter à{' '}
                      <a href="mailto:contact@vitriz.org" className="text-blue-400 hover:text-blue-300">
                        contact@vitriz.org
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
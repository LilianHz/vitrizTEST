import { motion, AnimatePresence } from 'framer-motion';
import { X, Mail, User, Building, Copy } from 'lucide-react';
import { useState, useEffect } from 'react';

export function LeadCaptureForm() {
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  useEffect(() => {
    if (isDismissed) return;

    const timeoutId = setTimeout(() => {
      setIsVisible(true);
    }, 30000);

    const handleScroll = () => {
      const scrollHeight = document.documentElement.scrollHeight;
      const scrollTop = window.scrollY;
      const clientHeight = document.documentElement.clientHeight;
      const scrollPercentage = (scrollTop / (scrollHeight - clientHeight)) * 100;

      if (scrollPercentage > 75) {
        setIsVisible(true);
      }
    };

    window.addEventListener('scroll', handleScroll);

    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('scroll', handleScroll);
    };
  }, [isDismissed]);

  const handleClose = () => {
    setIsVisible(false);
    setIsDismissed(true);
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);

    fetch("/", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(formData as any).toString()
    })
      .then(() => {
        setIsSubmitted(true);
      })
      .catch((error) => {
        console.error("Form submission error:", error);
        alert("Une erreur est survenue. Veuillez réessayer.");
      });
  };

  const copyPromoCode = () => {
    navigator.clipboard.writeText('START60');
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      {isVisible && !isDismissed && (
        <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-lg bg-gray-900/95 backdrop-blur-lg rounded-2xl border border-gray-700 shadow-xl overflow-hidden"
          >
            <button
              onClick={handleClose}
              className="absolute top-4 right-4 p-2 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 
                       border border-gray-700 hover:border-gray-600 transition-all duration-200"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>

            <div className="p-8">
              {isSubmitted ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center"
                >
                  <h2 className="text-3xl font-bold text-white mb-4">🎉 Félicitations !</h2>
                  <p className="text-xl text-blue-200 mb-6">
                    Voici votre code promo exclusif :
                  </p>
                  <div className="relative group">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                                rounded-xl blur-xl opacity-75 group-hover:opacity-100 transition duration-300" />
                    <button
                      onClick={copyPromoCode}
                      className="relative w-full bg-gray-800/50 backdrop-blur-lg p-4 rounded-xl border 
                              border-gray-700 hover:border-blue-500 transition-all duration-300
                              flex items-center justify-center gap-3"
                    >
                      <span className="text-2xl font-bold text-white">START60</span>
                      <Copy className={`w-5 h-5 ${isCopied ? 'text-green-400' : 'text-blue-400'}`} />
                    </button>
                  </div>
                  <p className="text-sm text-gray-400 mt-4">
                    {isCopied ? 'Code copié !' : 'Cliquez pour copier le code'}
                  </p>
                </motion.div>
              ) : (
                <>
                  <h2 className="text-3xl font-bold text-white mb-2">
                    Découvrez votre potentiel et économisez !
                  </h2>
                  <p className="text-blue-200 mb-6">
                    Obtenez une analyse gratuite de votre présence en ligne + un code promo exclusif de -60%.
                  </p>

                  <form
                    name="contact"
                    method="POST"
                    onSubmit={handleSubmit}
                    className="space-y-4"
                  >
                    <input type="hidden" name="form-name" value="contact" />
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1" htmlFor="name">
                        Nom complet
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <User className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          type="text"
                          name="name"
                          id="name"
                          required
                          className="block w-full pl-10 pr-3 py-2 border border-gray-700 rounded-lg
                                   bg-gray-800/50 text-white placeholder-gray-400
                                   focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="Jean Dupont"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1" htmlFor="email">
                        Email professionnel
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Mail className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          type="email"
                          name="email"
                          id="email"
                          required
                          className="block w-full pl-10 pr-3 py-2 border border-gray-700 rounded-lg
                                   bg-gray-800/50 text-white placeholder-gray-400
                                   focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="jean@entreprise.fr"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1" htmlFor="company">
                        Nom de l'entreprise
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Building className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          type="text"
                          name="company"
                          id="company"
                          required
                          className="block w-full pl-10 pr-3 py-2 border border-gray-700 rounded-lg
                                   bg-gray-800/50 text-white placeholder-gray-400
                                   focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="Entreprise SARL"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white 
                               font-semibold py-3 px-4 rounded-lg hover:from-blue-700 
                               hover:to-blue-800 transition-all duration-200 flex items-center justify-center gap-2"
                    >
                      <span>👉 Obtenir mon analyse gratuite + mon code -60%</span>
                    </button>

                    <p className="text-xs text-gray-400 mt-4 text-center">
                      En soumettant ce formulaire, vous recevrez votre analyse gratuite ainsi qu'un code promo exclusif. 
                      Vous acceptez également de recevoir des communications de notre part.
                    </p>
                  </form>
                </>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
import { motion } from 'framer-motion';
import { Target } from 'lucide-react';

export function ReassuranceBadge() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="inline-flex items-center gap-2 bg-gradient-to-r from-green-500/20 to-green-600/20 
                backdrop-blur-md rounded-full px-3 py-1.5 sm:px-4 sm:py-2 border border-green-400/20"
    >
      <Target className="w-3 h-3 sm:w-4 sm:h-4 text-green-400" />
      <span className="text-white text-xs sm:text-sm font-semibold">
        Résultats garantis
      </span>
    </motion.div>
  );
}
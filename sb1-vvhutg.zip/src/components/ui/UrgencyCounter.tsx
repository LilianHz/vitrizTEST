import { motion } from 'framer-motion';
import { Clock } from 'lucide-react';
import { useState, useEffect } from 'react';

export function UrgencyCounter() {
  const [timeLeft, setTimeLeft] = useState({
    days: 6,
    hours: 23,
    minutes: 59,
    seconds: 59
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        }
        return { days: 6, hours: 23, minutes: 59, seconds: 59 };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center gap-2"
    >
      <div className="inline-flex items-center gap-2 bg-gradient-to-r from-red-500/20 to-red-600/20 
                    backdrop-blur-md rounded-full px-3 py-1.5 sm:px-4 sm:py-2 border border-red-400/20">
        <Clock className="w-3 h-3 sm:w-4 sm:h-4 text-red-400" />
        <span className="text-white text-xs sm:text-sm font-semibold">
          Offre d'essai gratuit disponible uniquement cette semaine !
        </span>
      </div>
      <div className="flex items-center gap-2 sm:gap-4 text-xs sm:text-sm">
        <div className="text-center">
          <span className="text-red-400 font-bold">{timeLeft.days}</span>
          <span className="text-gray-400 ml-1">j</span>
        </div>
        <span className="text-gray-400">:</span>
        <div className="text-center">
          <span className="text-red-400 font-bold">{timeLeft.hours.toString().padStart(2, '0')}</span>
          <span className="text-gray-400 ml-1">h</span>
        </div>
        <span className="text-gray-400">:</span>
        <div className="text-center">
          <span className="text-red-400 font-bold">{timeLeft.minutes.toString().padStart(2, '0')}</span>
          <span className="text-gray-400 ml-1">m</span>
        </div>
        <span className="text-gray-400">:</span>
        <div className="text-center">
          <span className="text-red-400 font-bold">{timeLeft.seconds.toString().padStart(2, '0')}</span>
          <span className="text-gray-400 ml-1">s</span>
        </div>
      </div>
    </motion.div>
  );
}
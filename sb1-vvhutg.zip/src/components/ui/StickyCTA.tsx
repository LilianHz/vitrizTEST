import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './Button';
import { trackEvent } from '../../utils/analytics';
import { redirectTo } from '../../utils/navigation';
import { useState, useEffect } from 'react';

export function StickyCTA() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const threshold = window.innerHeight * 0.5;
      setIsVisible(scrollY > threshold);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleClick = () => {
    trackEvent.startTrial();
    redirectTo.stripe();
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          className="fixed bottom-8 right-8 z-40"
        >
          <Button
            text="Essayez gratuitement et boostez vos avis !"
            onClick={handleClick}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
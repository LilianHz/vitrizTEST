import { motion } from 'framer-motion';

interface SubtextProps {
  text: string;
}

export function Subtext({ text }: SubtextProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.2, duration: 0.8 }}
      className="flex items-center justify-center gap-3 text-blue-200"
    >
      <div className="w-5 h-px bg-blue-400/30" />
      <span>{text}</span>
      <div className="w-5 h-px bg-blue-400/30" />
    </motion.div>
  );
}
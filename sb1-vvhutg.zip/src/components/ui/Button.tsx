import { ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

interface ButtonProps {
  text: string;
  onClick: () => void;
  withArrow?: boolean;
}

export function Button({ text, onClick, withArrow = true }: ButtonProps) {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="relative group max-w-full"
    >
      {/* Animated gradient background */}
      <div className="absolute -inset-1 bg-gradient-to-r from-blue-700 via-violet-600 to-blue-700 
                    rounded-full blur-xl opacity-70 group-hover:opacity-100 transition duration-300
                    animate-gradient" />
      
      {/* Border container */}
      <div className="relative p-[2px] bg-gradient-to-r from-blue-700 via-violet-600 to-blue-700 
                    rounded-full animate-gradient bg-[length:200%_200%]">
        {/* Button content */}
        <div className="relative bg-gradient-to-r from-blue-700 via-violet-600 to-blue-700 text-white 
                      px-4 sm:px-8 py-3 rounded-full font-semibold text-sm sm:text-base shadow-lg 
                      hover:shadow-xl flex items-center justify-center gap-2 transition-all duration-300 
                      w-full sm:w-auto bg-[length:200%_200%] animate-gradient
                      border border-white/10">
          <span className="text-center whitespace-normal sm:whitespace-nowrap">{text}</span>
          {withArrow && (
            <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0 group-hover:translate-x-1 transition-transform duration-300" />
          )}
        </div>
      </div>
    </motion.button>
  );
}
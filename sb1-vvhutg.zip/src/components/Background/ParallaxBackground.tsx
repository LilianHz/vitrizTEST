interface ParallaxBackgroundProps {
  scrollY: number;
}

export function ParallaxBackground({ scrollY }: ParallaxBackgroundProps) {
  // Detect mobile devices
  const isMobile = window.innerWidth <= 768;
  
  // Enhanced scaling values for mobile
  const mobileScale = 1 + (scrollY * 0.0003); // More pronounced scaling for mobile
  const mobileBlur = Math.min(scrollY * 0.02, 8); // Faster blur effect
  
  // Desktop values remain more subtle
  const desktopScale = 1 + (scrollY * 0.0001);
  const desktopBlur = Math.min(scrollY * 0.01, 6);
  
  // Use appropriate values based on device
  const scale = isMobile ? mobileScale : desktopScale;
  const blur = isMobile ? mobileBlur : desktopBlur;

  return (
    <>
      {/* Background image with enhanced parallax effect */}
      <div 
        className="fixed inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80')] 
                  bg-cover bg-center bg-no-repeat will-change-transform"
        style={{ 
          transform: `scale(${scale})`,
          filter: `blur(${blur}px)`,
          transition: 'transform 800ms ease-out, filter 600ms ease-out'
        }}
      />
      
      {/* Overlay gradient with increased opacity */}
      <div className="fixed inset-0 bg-gradient-to-br from-gray-900/99 via-blue-900/99 to-gray-900/99" />
    </>
  );
}
import { CircleDollarSign, Sparkles, Shield, Wrench, HelpCircle } from 'lucide-react';
import type { FAQ } from './types';

export const faqs: FAQ[] = [
  {
    icon: Sparkles,
    question: 'Est-ce que cela fonctionne vraiment ?',
    answer: 'Notre technologie, testée et approuvée par plus de 1 200 entreprises, a déjà généré plus de 12 000 avis 5 étoiles.',
    benefits: [
      'Augmentation moyenne de 400% des avis positifs en moins d\'un mois',
      'Classement Top 3 Google garanti',
      'Résultats visibles dès la première semaine'
    ],
    highlights: [
      '✨ Plus de 12 000 avis générés',
      '🏆 Plus de 1 200 entreprises nous font confiance'
    ]
  },
  {
    icon: Wrench,
    question: 'Dois-je être un expert technique pour utiliser ce logiciel ?',
    answer: 'Non. L\'installation se fait en quelques minutes, sans compétences particulières.',
    benefits: [
      'Installation guidée en moins de 5 minutes',
      'Interface utilisateur intuitive',
      'Support technique disponible 7j/7'
    ]
  },
  {
    icon: Shield,
    question: 'Y a-t-il un engagement ?',
    answer: 'Aucun engagement. Vous pouvez arrêter à tout moment, sans frais cachés.',
    benefits: [
      'Sans engagement de durée',
      'Annulation simple et rapide',
      'Essai gratuit disponible'
    ]
  },
  {
    icon: CircleDollarSign,
    question: 'Combien cela coûte-t-il ?',
    answer: 'Exceptionnellement, le premier mois est à 27€ au lieu de 69€ ! Une offre limitée à saisir rapidement.',
    benefits: [
      'Augmentation moyenne des ventes de 30%',
      'ROI positif dès le premier mois',
      'Essai gratuit disponible'
    ],
    highlights: [
      '💰 Offre exceptionnelle : 27€ le premier mois au lieu de 69€',
      '📈 Retour sur investissement moyen : 300% en 3 mois'
    ]
  },
  {
    icon: HelpCircle,
    question: 'Que se passe-t-il si je reçois un avis négatif ?',
    answer: 'Notre système le gère en privé, vous permettant d\'agir avant que cela n\'affecte votre réputation.',
    benefits: [
      'Alertes instantanées pour chaque nouvel avis',
      'Gestion privée des retours négatifs',
      'Suggestions de réponses personnalisées'
    ],
    highlights: [
      '🛡️ Protection proactive de votre e-réputation',
      '✉️ Communication privée avec les clients insatisfaits'
    ]
  }
];
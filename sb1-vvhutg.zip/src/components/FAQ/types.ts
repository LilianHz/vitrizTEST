import { LucideIcon } from 'lucide-react';

export interface FAQ {
  question: string;
  answer: string;
  benefits?: string[];
  highlights?: string[];
  icon?: LucideIcon;
}
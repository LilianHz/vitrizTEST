import { Check } from 'lucide-react';

interface FAQContentProps {
  answer: string;
  benefits?: string[];
  highlights?: string[];
}

export function FAQContent({ answer, benefits, highlights }: FAQContentProps) {
  return (
    <div className="p-6 pt-0 space-y-4">
      <p className="text-gray-300">{answer}</p>
      
      {benefits && benefits.length > 0 && (
        <div className="space-y-2">
          <p className="text-white font-semibold">Avantages clés :</p>
          <ul className="space-y-2">
            {benefits.map((benefit, index) => (
              <li key={index} className="flex items-start gap-2">
                <Check className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                <span className="text-gray-300">{benefit}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {highlights && highlights.length > 0 && (
        <div className="bg-blue-900/20 border border-blue-500/20 rounded-lg p-4 space-y-2">
          {highlights.map((highlight, index) => (
            <p key={index} className="text-blue-200 font-medium">
              {highlight}
            </p>
          ))}
        </div>
      )}
    </div>
  );
}
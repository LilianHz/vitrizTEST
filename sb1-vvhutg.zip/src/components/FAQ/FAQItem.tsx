import { motion } from 'framer-motion';
import { HelpCircle, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { FAQContent } from './FAQContent';
import type { FAQ } from './types';

interface FAQItemProps extends FAQ {
  index: number;
}

export function FAQItem({ question, answer, benefits, highlights, icon: Icon, index }: FAQItemProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="relative group"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 
                    rounded-2xl blur-xl opacity-75 group-hover:opacity-100 transition duration-300" />
      <div className="relative bg-gray-800/50 backdrop-blur-lg rounded-2xl border 
                    border-gray-700 hover:border-blue-500 transition-all duration-300 overflow-hidden">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full p-6 text-left flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <div className="p-2 rounded-lg bg-gradient-to-r from-blue-500/20 to-blue-600/20">
              {Icon ? <Icon className="w-6 h-6 text-blue-400" /> : <HelpCircle className="w-6 h-6 text-blue-400" />}
            </div>
            <h3 className="text-lg font-semibold text-white">{question}</h3>
          </div>
          <ChevronDown
            className={`w-5 h-5 text-blue-400 transition-transform duration-300 ${
              isOpen ? 'rotate-180' : ''
            }`}
          />
        </button>
        <motion.div
          initial={false}
          animate={{ height: isOpen ? 'auto' : 0 }}
          transition={{ duration: 0.3 }}
          className="overflow-hidden"
        >
          <FAQContent 
            answer={answer}
            benefits={benefits}
            highlights={highlights}
          />
        </motion.div>
      </div>
    </motion.div>
  );
}